# Claude Mobile Pro 2.0

A mobile-first Claude-style AI workspace using **Puter.js for AI**. The Android wrapper contains no Anthropic API key. Puter.js provides access to Claude and other models and supports streaming and tool calling; usage/authentication follows Puter's current platform model.

## What is implemented
- Android WebView shell with deep-link handling for GitHub OAuth
- Puter.js Claude chat with streaming responses
- Model selector
- Persistent chats, projects, plugin definitions and checkpoints in localStorage
- Plugin creation flow: requirement -> AI-generated JSON preview -> local install
- Project Builder: project goal -> AI-generated structured spec
- GitHub OAuth backend bridge + repository listing
- Deployment workspace placeholder with explicit provider boundary
- Destructive plugin deletion confirmation
- Dark-first mobile UI, drawer navigation, attachment menu and settings

## Important limitations
This repository is an honest working foundation, not a claim that every item in a very large production spec is finished. Native camera/photo/document capture UI, full GitHub file/branch/commit CRUD, real deployment adapters, sandboxed third-party plugin execution, and a full code editor still need dedicated implementation. The app does not pretend those operations succeeded.

## Puter.js
The app loads `https://js.puter.com/v2/` and calls `puter.ai.chat()` with Claude models. No `ANTHROPIC_API_KEY` is required in the app. See the current Puter documentation for model availability, streaming, tool calling, quotas and the User-Pays model.

## Android build
Open this folder in Android Studio with Android SDK 35 installed and run `assembleDebug`. This environment did not contain the Android SDK/Gradle toolchain, so an APK could not be truthfully compiled here.

## Backend
The backend is only for GitHub OAuth and project checkpoint persistence. It does **not** proxy Anthropic API calls.

1. `cd backend`
2. `cp .env.example .env`
3. Fill GitHub OAuth values.
4. `npm install && npm start`
5. In the app, set Backend URL in Settings.

The GitHub OAuth callback uses a short-lived, one-time exchange code and does not persist the GitHub access token to disk.
